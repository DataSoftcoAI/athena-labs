from vgt_core.core.vgt_core_v0_3 import VGTCoreV03
import torch

model = VGTCoreV03()
node_features = torch.randn(5, 16)
edge_features = torch.randn(5, 5, 4)
adj_mask = torch.ones(5, 5)
out, attn = model(node_features, edge_features, adj_mask)
print("✅ Output shape:", out.shape)
