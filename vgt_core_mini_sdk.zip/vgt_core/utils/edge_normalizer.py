import torch

class EdgeNormalizer:
    """Normalize edge features: [distance, angle, cos, sin]."""
    def __init__(self):
        self.eps = 1e-6

    def __call__(self, edge_features):
        # edge_features: [N, N, 4]
        dist = edge_features[..., 0]
        angle = edge_features[..., 1]
        cos_a = edge_features[..., 2]
        sin_a = edge_features[..., 3]

        dist_norm = (dist - dist.mean()) / (dist.std() + self.eps)
        angle_norm = (angle - angle.mean()) / (angle.std() + self.eps)

        return torch.stack([dist_norm, angle_norm, cos_a, sin_a], dim=-1)
