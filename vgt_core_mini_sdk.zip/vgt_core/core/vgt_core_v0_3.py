import torch
import torch.nn as nn
import torch.nn.functional as F

class VGTCoreV03(nn.Module):
    def __init__(self, embed_dim=16, num_heads=4, disentangle=True):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.disentangle = disentangle

        self.q_proj = nn.Linear(embed_dim, embed_dim)
        self.k_proj = nn.Linear(embed_dim, embed_dim)
        self.v_proj = nn.Linear(embed_dim, embed_dim)

        self.edge_mlps = nn.ModuleList([
            nn.Sequential(
                nn.Linear(4, 8),
                nn.ReLU(),
                nn.Linear(8, 1)
            ) for _ in range(num_heads)
        ])

        self.output_proj = nn.Linear(embed_dim, embed_dim)
        self.layer_norm = nn.LayerNorm(embed_dim)
        self.dropout = nn.Dropout(0.1)

    def forward(self, node_features, edge_features, adj_mask):
        N = node_features.size(0)
        Q = self.q_proj(node_features).view(N, self.num_heads, self.head_dim)
        K = self.k_proj(node_features).view(N, self.num_heads, self.head_dim)
        V = self.v_proj(node_features).view(N, self.num_heads, self.head_dim)

        attention_weights = []
        head_outputs = []
        for h in range(self.num_heads):
            attn_scores = torch.einsum('id,jd->ij', Q[:, h], K[:, h]) / (self.head_dim ** 0.5)
            edge_scores = self.edge_mlps[h](edge_features).squeeze(-1)
            attn_scores += edge_scores
            attn_scores = attn_scores * adj_mask - 1e10 * (1 - adj_mask)
            attn_weights = F.softmax(attn_scores, dim=-1)
            attention_weights.append(attn_weights)
            head_output = torch.mm(attn_weights, V[:, h])
            head_outputs.append(head_output)

        output = torch.cat(head_outputs, dim=-1)
        output = self.output_proj(output)
        output = self.dropout(self.layer_norm(output))

        return output, torch.stack(attention_weights)
