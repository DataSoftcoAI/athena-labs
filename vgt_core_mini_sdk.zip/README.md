# VGT-Core Mini SDK

This lightweight version includes core model and edge normalization utility for experimentation.
